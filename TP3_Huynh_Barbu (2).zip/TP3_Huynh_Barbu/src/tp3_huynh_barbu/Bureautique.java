/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3_huynh_barbu;

/**
 *
 * @author 1525682
 */
public class Bureautique {
    double versionDuLogiciel;
}
