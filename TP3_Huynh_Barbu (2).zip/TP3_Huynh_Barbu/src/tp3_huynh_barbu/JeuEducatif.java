/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3_huynh_barbu;

/**
 *
 * @author 1525682
 */
public class JeuEducatif {
    public enum classement {
        JEUNESENFANTS,
        ENFANTSETADULTES,
        ADOLESCENTS,
        JEUNESADULTES,
    };
    private boolean microTransaction;
    private int ageOptimal;
    
    public void setMicroTransaction(boolean microTransaction){
        this.microTransaction=microTransaction;
    }
    public void setAgeOptimal(int ageOptimal){
        this.ageOptimal=ageOptimal;
    }
}
