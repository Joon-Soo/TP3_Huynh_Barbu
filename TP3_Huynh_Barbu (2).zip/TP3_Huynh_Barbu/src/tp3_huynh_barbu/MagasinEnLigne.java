/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3_huynh_barbu;

import java.util.Scanner;

/**
 *
 * @author 1525682
 */
public class MagasinEnLigne extends Logiciel {
    
    public MagasinEnLigne() {
        
    }
    
    private void Affichage() {
        System.out.print("Bienvenue au magasin en ligne de Windows"
                + "\n 1. Informations"
                + "\n 2. Saisir un nouveau logiciel"
                + "\n 3. Modifier ou supprimer un logiciel existant"
                + "\n 4. Quitter"
                + "\nVeuillez choisir une des options suivantes:");
    }
    
    public void executer() {
        boolean erreur = true;
        Scanner scanner = new Scanner(System.in);
        while (erreur) {
            String entree;
            Affichage();
            entree = scanner.nextLine();
            switch (entree) {
                case "1":
                    erreur = false;
                    break;
                case "2":
                    nouveauLogiciel();
                    erreur = false;
                    break;
                case "3":
                    erreur = false;
                    break;
                case "4":
                    erreur = false;
                    break;
                default:
            }
        }
    }

    private void nouveauLogiciel() {

        Logiciel logiciel = new Logiciel();
        logiciel.setNomLogiciel(poserQuestion("Que sera le nom du nouveau logiciel?"));
        logiciel.setPrixVente(Double.parseDouble(poserQuestion("Quel sera le prix de vente du logiciel?")));
        do {
        } while (cote > 5);
        logiciel.setCote(Integer.parseInt(poserQuestion("Que sera la cote du logiciel?")));
        logiciel.setNomDuDeveloppeur(poserQuestion("Quel est le nom du developpeur pour ce logiciel?"));
    }

    private void menuTypeLogiciel() {
        System.out.print("Type de logiciel"
                + "\n 1. Jeu de divertissement"
                + "\n 2. Jeu educatif"
                + "\n 3. Jeu Free To Play"
                + "\n 4. Bureatique"
                + "\n 5. Utilitaire"
                + "\nQuelle type de logiciel voulez-vous creer ? ");
    }
    
    public String poserQuestion(String question){
        Scanner scanner = new Scanner(System.in);
        System.out.println(question);
        return scanner.nextLine();
    }
}
