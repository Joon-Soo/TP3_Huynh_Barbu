package tp3_huynh_barbu;

/**
 *
 * @author 1525682
 */
public class TP3_Huynh_Barbu {


    public static void main(String[] args) {
       WindowsStore windowsStore = new WindowsStore();
    }
    
}
