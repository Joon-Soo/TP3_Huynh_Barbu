/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp3_huynh_barbu;

import java.util.Scanner;

/**
 *
 * @author 1525682
 */
public class WindowsStore {

    private String utilisateur;
    private String motDePasse;

    public WindowsStore() {

    }

    public void jouer() {
        Scanner scanner = new Scanner(System.in);
        boolean login = false;
        int compteur = 0;
        do{
            System.out.print("Bienvenue dans le Windows Store"
                    + "\nVeuiller entrer votre nom d'utilisateur: ");
            utilisateur = scanner.nextLine();
            System.out.print("Veuillez entrer votre mot de passe: ");
            motDePasse = scanner.nextLine();
            if (false) {
            // methode pour voir si le truc est bon
                compteur++;
                if(compteur==3){
                    System.exit(0);
                }
            } else if (true) {
                // methode pour voir si le truc est bon
                login = true;
            }
        }while (login);
    }
    
    public String getUtilisateur(){
        return utilisateur;
    }
    
    public String getMotDePasse(){
        return motDePasse;
    }

}
